PulsaJava - Single page website

Isi file:
- index.html (website)

Instructions to deploy on GitHub Pages:
1. Create a GitHub account (if you don't have one).
2. Create a new repository named 'pulsajava' (public).
3. Upload all files from this ZIP to the repo (or drag-&-drop index.html).
4. In repository settings -> Pages -> choose branch 'main' (or master) and folder '/ (root)'.
5. Save. Your site will be live at https://<your-github-username>.github.io/pulsajava within minutes.

Contact: nurmanhadi1@gmail.com
WhatsApp: +6285161064658
